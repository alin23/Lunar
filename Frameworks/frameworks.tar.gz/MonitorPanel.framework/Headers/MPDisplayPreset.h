#import "CoreFoundation/CoreFoundation.h"
#import "Cocoa/Cocoa.h"

@class NSMutableDictionary, NSDictionary, NSString;

@interface MPDisplayPreset : NSObject
{
    unsigned int _displayID;
    NSString *_presetName;
    NSDictionary *_presetDictionary;
    unsigned long long _presetIndex;
    BOOL _isWritable;
    long long _presetGroup;
}

@property(readonly) long long presetGroup; // @synthesize presetGroup=_presetGroup;
@property(readonly) BOOL isWritable; // @synthesize isWritable=_isWritable;
@property(readonly) unsigned long long presetIndex; // @synthesize presetIndex=_presetIndex;
@property(readonly) NSDictionary *presetDictionary; // @synthesize presetDictionary=_presetDictionary;
@property(readonly) unsigned int displayID; // @synthesize displayID=_displayID;
- (void)_safeCopyKey:(NSString *)arg1 fromDict:(NSDictionary *)arg2 toDict:(NSDictionary *)arg3;
- (NSMutableDictionary *)_mutableDictionaryWithNewSettings:(NSDictionary *)arg1;
- (void)_initializeWithIndex:(unsigned int)arg1 dictionary:(CFDictionaryRef)arg2 forDisplayID:(unsigned int)arg3;
- (NSString *)_getStringFromStringRef:(CFStringRef)arg1;
@property(readonly) NSString *presetName;
@property(readonly) NSString *presetDescription;
- (BOOL)makeValidWithSettings:(NSDictionary *)arg1;
- (BOOL)makeInvalid;
@property(readonly) BOOL isValid;
- (void)dealloc;
- (MPDisplayPreset *)initWithIndex:(unsigned long long)arg1 dictionary:(CFDictionaryRef)arg2 forDisplayID:(unsigned int)arg3;

@end


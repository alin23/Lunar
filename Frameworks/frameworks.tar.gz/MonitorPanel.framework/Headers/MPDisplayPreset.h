@interface MPDisplayPreset : NSObject
{
    unsigned int _displayID;
    NSString *_presetName;
    NSDictionary *_presetDictionary;
    unsigned long long _presetIndex;
    BOOL _isWritable;
    long long _presetGroup;
}

@property(readonly) long long presetGroup; // @synthesize presetGroup=_presetGroup;
@property(readonly) BOOL isWritable; // @synthesize isWritable=_isWritable;
@property(readonly) unsigned long long presetIndex; // @synthesize presetIndex=_presetIndex;
@property(readonly) NSDictionary *presetDictionary; // @synthesize presetDictionary=_presetDictionary;
@property(readonly) unsigned int displayID; // @synthesize displayID=_displayID;
- (void)_safeCopyKey:(id)arg1 fromDict:(id)arg2 toDict:(id)arg3;
- (id)_mutableDictionaryWithNewSettings:(id)arg1;
- (void)_initializeWithIndex:(unsigned int)arg1 dictionary:(struct __CFDictionary *)arg2 forDisplayID:(unsigned int)arg3;
- (id)_getStringFromStringRef:(struct __CFString *)arg1;
@property(readonly) NSString *presetName;
@property(readonly) NSString *presetDescription;
- (BOOL)makeValidWithSettings:(id)arg1;
- (BOOL)makeInvalid;
@property(readonly) BOOL isValid;
- (void)dealloc;
- (id)initWithIndex:(unsigned int)arg1 dictionary:(struct __CFDictionary *)arg2 forDisplayID:(unsigned int)arg3;

@end

